function JSONPreview(ref) {
    if(!ref){
        throw "Refrence error.."
    }
    this.Indent = []
    var table = document.createElement("table")
    var tr = document.createElement("tr")
    tr.setAttribute("style","text-align:center;font-weight: 1000;")
    tr.insertCell()
    tr.insertCell()
    tr.insertCell()
    tr.cells[0].innerHTML = "#"
    tr.cells[1].innerHTML = "Old Value"
    tr.cells[2].innerHTML = "New Value"
    table.appendChild(tr)

    table.setAttribute("border",1)
    table.setAttribute("cellspacing",0)
    table.setAttribute("cellpadding",0)
    ref.appendChild(table);
    this.Container = table
    return this;
}

JSONPreview.prototype.PreviewJson = function (oldjson,newjson) {
    if(Array.isArray(oldjson)){
        this.PreviewArrayElems(oldjson,newjson)
    }else if(typeof oldjson == "object"){
        this.PreviewObjectAttrs(oldjson,newjson)
    }
}

JSONPreview.prototype.PreviewArrayElems = function (oldArray,newArray,key) {
    var Arr = oldArray
    if(oldArray.length<newArray.length){
        Arr = newArray
    }
    for (var i = 0; i < Arr.length; i++) {
        var OldValue = oldArray[i]
        var NewValue = newArray[i]
        if(Array.isArray(OldValue) && Array.isArray(NewValue)){
            var tr = document.createElement("tr")
            tr.insertCell()
            tr.cells[0].setAttribute("colspan",3)
            tr.cells[0].innerHTML =  this.Indent.join("") + key || ""
            this.Container.appendChild(tr)
            this.PreviewArrayElems(OldValue,NewValue)
        }else if(typeof OldValue != "object" && typeof NewValue != "object"){
            var tr = document.createElement("tr")
            tr.insertCell()
            tr.insertCell()
            tr.insertCell()
            if(i == 0)
                tr.cells[0].innerHTML = this.Indent.join("") +"<b>" + key + "</b>" || ""
            tr.cells[1].innerHTML = OldValue ? this.Indent.join("") + OldValue : ""
            tr.cells[2].innerHTML = NewValue ? this.Indent.join("") + NewValue : ""
            this.Container.appendChild(tr)
        }else if(typeof OldValue == "object" && typeof NewValue == "object"){
            var tr = document.createElement("tr")
            tr.insertCell()
            tr.cells[0].setAttribute("colspan",3)    
            tr.cells[0].innerHTML =  this.Indent.join("") + "<b>" +key + "</b>"+ " -> " + i  || ""
            this.Container.appendChild(tr)    
            this.PreviewObjectAttrs(OldValue,NewValue)
        }
    }
}

JSONPreview.prototype.PreviewObjectAttrs = function (oldObject,newObject) {
    this.AddIndent()
    var NewKeylength = Object.keys(newObject).length
    var OldKeylength = Object.keys(oldObject).length

    var array2operate = oldObject
    if(NewKeylength>OldKeylength){
        array2operate = newObject
    }
    for(var key in array2operate){
        var OldValue = oldObject[key]
        var NewValue = newObject[key]
        if(Array.isArray(OldValue) && Array.isArray(NewValue)){
            this.PreviewArrayElems(OldValue,NewValue,key)
        }else if(typeof OldValue != "object" && typeof NewValue != "object"){
            var tr = document.createElement("tr")
            tr.insertCell()
            tr.insertCell()
            tr.insertCell()
            tr.cells[0].innerHTML = this.Indent.join("") +"<b>"+ key + "</b>" || ""
            tr.cells[1].innerHTML = OldValue ? this.Indent.join("") + OldValue : ""
            tr.cells[2].innerHTML = NewValue ? this.Indent.join("") + NewValue : ""
            tr.cells[1].setAttribute("style","text-align:center;")
            tr.cells[2].setAttribute("style","text-align:center;")
            this.Container.appendChild(tr)
        }else if(typeof OldValue == "object" && typeof NewValue == "object"){
            var tr = document.createElement("tr")
            tr.insertCell()
            tr.cells[0].setAttribute("colspan",3)
            tr.cells[0].innerHTML =  this.Indent.join("") +"<b>"+  key + "</b>" || ""
            tr.style.textAlign = "left"
            this.Container.appendChild(tr)
            this.PreviewObjectAttrs(OldValue,NewValue)
        }
    }
    this.RemoveIndent()
}

JSONPreview.prototype.AddIndent = function () {
    this.Indent.push("&nbsp;")
    this.Indent.push("&nbsp;")
    this.Indent.push("&nbsp;")
    this.Indent.push("&nbsp;")
}

JSONPreview.prototype.RemoveIndent = function () {
    this.Indent.pop();
    this.Indent.pop();
    this.Indent.pop();
    this.Indent.pop();
}

